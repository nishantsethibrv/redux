import Products from "./Products";

const Dashboard = () => {
  return (
    <>
    <Products />
    </>
  )
}

export default Dashboard;